<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <?php
        include("config.php");
        $un = $_POST['username'];
        $pwd = $_POST['password'];
        $valid = false;

        $sql = "SELECT username,name FROM project3User WHERE username='$un' AND password='$pwd'";

        $result = $connection->query($sql);
        if ($result->num_rows >0){
            while($row=$result->fetch_assoc()){
                $_SESSION["name"] = $row["name"];
                echo "Welcome " . $row["name"]. "!<br>";
                $valid = true;
            }
        }

        if($valid==true){
            header("Location: menu.php");
        }
        else{
            echo "Wrong username or password! <br>";
            echo "<a href='login.html' class='button'> Try Again! </a>";
        }
        
        $connection->close;
    ?>
</body>
</html>