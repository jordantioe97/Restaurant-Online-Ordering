<!DOCTYPE html>
<?php
session_start();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Menu</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="menu.css">
    <link rel="stylesheet" type="text/css" media="screen" href="checkout.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
</head>

<body>
    <nav class="borderXwidth">
        <ul>
            <li><b>JJR Eats</b></li>
            <li><a href="index.html" class="Ani">Home</a></li>
            <li><a href="menu.php" class="Ani">Menu</a></li>
            <button  onclick="window.location.href='checkout.php'" type="button" id="myBtn" >Ready to Go?</button>
            <?php
            
            if($_SESSION['name'] == ""){
                echo "<li class='rightNav'><a href='login.html' class='Ani'>Login</a></li>";
                echo "<li class='rightNav'><a href='register.html' class='Ani'>SignUp!</a></li>";
            }
            else{
                echo "<li class='rightNav'><a href='logout.php' class='Ani'>Logout</a></li>";
                echo "<li class='rightNav'> Welcome  " . $_SESSION["name"] . "</li>";
            }
            ?>
        </ul>
    </nav>

    <!--Julio's code-->
    <div id="outside-container1">

        <div class="left-side">

            <div class="item-contanier">
                <p class="main-title">Appetizer</p>
                <div class="title" id="title-l1"></div>
                <img alt="" id="img-l1">
                <div class="desc" id="desc-l1"></div>
                <div class="price" id="price-l1"></div>
                <button type="submit" id="btn-l1" onclick="addToArray(this.id)" )>Add Item</button>
            </div>

            <div class="item-contanier-after">
                <div class="title" id="title-l2"></div>

                <img src="" alt="" id="img-l2">
                <div class="desc" id="desc-l2"></div>
                <div class="price" id="price-l2"></div>
                <button type="submit" id="btn-l2" onclick="addToArray(this.id)">Add Item</button>
            </div>

        </div>

        <div class="right-side">
            <div class="item-contanier">
                <div class="title" id="title-r1"></div>

                <img src="" alt="" id="img-r1">
                <div class="desc" id="desc-r1"></div>
                <div class="price" id="price-r1"></div>
                <button type="submit" id="btn-r1" onclick="addToArray(this.id)">Add Item</button>
            </div>
            <div class="item-contanier-after">
                <div class="title" id="title-r2"></div>

                <img src="" alt="" id="img-r2">
                <div class="desc" id="desc-r2"></div>
                <div class="price" id="price-r2"></div>
                <button type="submit" id="btn-r2" onclick="addToArray(this.id)">Add Item</button>
            </div>
        </div>

    </div>


    <div id="outside-container2">

        <div class="left-side">
            <div class="item-contanier">
                <p class="main-title-after">Entree</p>
                <div class="title" id="title-l3"></div>

                <img src="" alt="" id="img-l3">
                <div class="desc" id="desc-l3"></div>
                <div class="price" id="price-l3"></div>
                <button type="submit" id="btn-l3" onclick="addToArray(this.id)">Add Item</button>
            </div>
            <div class="item-contanier-after">
                <div class="title" id="title-l4"></div>

                <img src="" alt="" id="img-l4">
                <div class="desc" id="desc-l4"></div>
                <div class="price" id="price-l4"></div>
                <button type="submit" id="btn-l4" onclick="addToArray(this.id)">Add Item</button>
            </div>
        </div>

        <div class="right-side">
            <div class="item-contanier">
                <div class="title" id="title-r3"></div>

                <img src="" alt="" id="img-r3">
                <div class="desc" id="desc-r3">
                </div>
                <div class="price" id="price-r3"></div>
                <button type="submit" id="btn-r3" onclick="addToArray(this.id)">Add Item</button>
            </div>
            <div class="item-contanier-after">
                <div class="title" id="title-r4"></div>

                <img src="" alt="" id="img-r4">
                <div class="desc" id="desc-r4"></div>
                <div id="test">
                    <div class="price" id="price-r4"></div>
                    <button type="submit" id="btn-r4" onclick="addToArray(this.id)">Add Item</button>
                </div>
            </div>
        </div>
    </div>

    <div id="outside-container2">

        <div class="left-side">
            <div class="item-contanier">
                <p class="main-title-after">Sides</p>
                <div class="title" id="title-l5"></div>

                <img src="" alt="" id="img-l5">
                <div class="desc" id="desc-l5"></div>
                <div class="price" id="price-l5"></div>
                <button type="submit" id="btn-l5" onclick="addToArray(this.id)">Add Item</button>
            </div>
            <div class="item-contanier-after">
                <div class="title" id="title-l6"></div>

                <img src="" alt="" id="img-l6">
                <div class="desc" id="desc-l6"></div>
                <div class="price" id="price-l6"></div>
                <button type="submit" id="btn-l6" onclick="addToArray(this.id)">Add Item</button>
            </div>
        </div>

        <div class="right-side">
            <div class="item-contanier">
                <div class="title" id="title-r5"></div>

                <img src="" alt="" id="img-r5">
                <div class="desc" id="desc-r5"></div>
                <div class="price" id="price-r5"></div>
                <button type="submit" id="btn-r5" onclick="addToArray(this.id)">Add Item</button>
            </div>
            <div class="item-contanier-after">
                <div class="title" id="title-r6"></div>

                <img src="" alt="" id="img-r6">
                <div class="desc" id="desc-r6"></div>
                <div class="price" id="price-r6"></div>
                <button type="submit" id="btn-r6" onclick="addToArray(this.id)">Add Item</button>
            </div>
        </div>
    </div>

    <div id="outside-container2">

        <div class="left-side">
            <div class="item-contanier">
                <p class="main-title-after">Dessert</p>
                <div class="title" id="title-l7"></div>

                <img src="" alt="" id="img-l7">
                <div class="desc" id="desc-l7"></div>
                <div class="price" id="price-l7"></div>
                <button type="submit" id="btn-l7" onclick="addToArray(this.id)">Add Item</button>
            </div>
            <div class="item-contanier-after">
                <div class="title" id="title-l8"></div>

                <img src="" alt="" id="img-l8">
                <div class="desc" id="desc-l8"></div>
                <div class="price" id="price-l8"></div>
                <button type="submit" id="btn-l8" onclick="addToArray(this.id)">Add Item</button>
            </div>
        </div>

        <div class="right-side">
            <div class="item-contanier">
                <div class="title" id="title-r7"></div>
                <img src="" alt="" id="img-r7">
                <div class="desc" id="desc-r7"></div>
                <div class="price" id="price-r7"></div>
                <button type="submit" id="btn-r7" onclick="addToArray(this.id)">Add Item</button>
            </div>
            <div class="item-contanier-after">
                <div class="title" id="title-r8"></div>

                <img src="" alt="" id="img-r8">
                <div class="desc" id="desc-r8"></div>
                <div class="price" id="price-r8"></div>
                <button type="submit" id="btn-r8" onclick="addToArray(this.id)">Add Item</button>
            </div>
        </div>
    </div>
</body>
<!--End of Julio's code-->
<script src="menu.js"></script>

</html>