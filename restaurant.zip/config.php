<!DOCTYPE html>
<html>
<body>
<?php 
$serverName="localhost";
$userName="jtioe1";
$password="jtioe1";
$dbName="jtioe1";

$connection = new mysqli($serverName,$userName,$password,$dbName);
if($connection->connect_error){
    die("Connection failed: " . $connection->connect_error);
}
?> 
</body>
</html>

