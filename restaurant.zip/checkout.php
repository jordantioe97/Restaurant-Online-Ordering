<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" media="screen" href="c.css">
</head>
<body>

<nav class="borderXwidth">
        <ul>
            <li><b>JJR Eats</b></li>
            <li><a href="index.html" class="Ani">Home</a></li>
            <li><a href="menu.php" class="Ani">Menu</a></li>
        </ul>
    </nav>
	<?php include('formChecking.php'); ?>            
<div class="alert alert-light alert-dismissible" role="alert"><strong><?= $validation; ?></strong>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="infoContainer">
<h1>
<center>Guest Checkout</center>
</h1>
<h4>Items in cart: </h4>
<div class="checkoutContainer" id="checkoutCont">
<!--Add Number of items in the cart here, along with each product and total-->
</div>
<form action= "<?= $_SERVER['PHP_SELF']; ?>" method="post">
<div class="container">
<h2>Shipping Address</h2><br>
Name:<br>
<input type="text" name="name" placeholder="Firstname Lastname" value="<?= $name ?>"><br>
<span class="error"><font color="red"><?=$name_error ?></font></span><br></br>
Email:<br>
<input type="text" name="email" placeholder="Enter email address" value="<?= $email ?>"><br>
<span class="error"><font color="red"><?=$email_error ?></font></span><br></br>
Address:<br>
<input type="text" name="address" placeholder="Enter shipping address" value="<?= $address ?>"><br>
<span class="error"><font color="red"><?=$address_error ?></font></span><br></br>
City:<br>
<input type="text" name="city" placeholder="Enter city" value="<?= $city ?>"><br>
<span class="error"><font color="red"><?=$city_error ?></font></span><br></br>
State:<br>
<select>
	<option value="AL">AL</option>
	<option value="AK">AK</option>
	<option value="AZ">AZ</option>
	<option value="AR">AR</option>
	<option value="CA">CA</option>
	<option value="CO">CO</option>
	<option value="CT">CT</option>
	<option value="DE">DE</option>
	<option value="DC">DC</option>
	<option value="FL">FL</option>
	<option value="GA">GA</option>
	<option value="HI">HI</option>
	<option value="ID">ID</option>
	<option value="IL">IL</option>
	<option value="IN">IN</option>
	<option value="IA">IA</option>
	<option value="KS">KS</option>
	<option value="KY">KY</option>
	<option value="LA">LA</option>
	<option value="ME">ME</option>
	<option value="MD">MD</option>
	<option value="MA">MA</option>
	<option value="MI">MI</option>
	<option value="MN">MN</option>
	<option value="MS">MS</option>
	<option value="MO">MO</option>
	<option value="MT">MT</option>
	<option value="NE">NE</option>
	<option value="NV">NV</option>
	<option value="NH">NH</option>
	<option value="NJ">NJ</option>
	<option value="NM">NM</option>
	<option value="NY">NY</option>
	<option value="NC">NC</option>
	<option value="ND">ND</option>
	<option value="OH">OH</option>
	<option value="OK">OK</option>
	<option value="OR">OR</option>
	<option value="PA">PA</option>
	<option value="RI">RI</option>
	<option value="SC">SC</option>
	<option value="SD">SD</option>
	<option value="TN">TN</option>
	<option value="TX">TX</option>
	<option value="UT">UT</option>
	<option value="VT">VT</option>
	<option value="VA">VA</option>
	<option value="WA">WA</option>
	<option value="WV">WV</option>
	<option value="WI">WI</option>
	<option value="WY">WY</option>
</select><br></br><br>
Zip Code:<br>
<input type="text" name="zipcode" placeholder="Enter zipcode" value="<?= $zipcode ?>"><br>
<span class="error"><font color="red"><?=$zip_error ?></font></span><br></br>
<!-- Credit card 15-16 digits.....card expiration date (MM/YY) -->
<!-- Security card- 3-4 digits -->
<h2>Payment Method (VISA, MasterCard, American Express, or Discover)</h2><br>
Credit Card Number:<br>
<input type="text" id="ccn" name="ccn" placeholder="Enter credit card number" value="<?= $ccn ?>" onblur="creditCard()">
<img id="cc-icon" src="ccicon/visa.png" alt="visa icon" width="40" height="30">
<img id="cc-icon" src="ccicon/mastercard.png" alt="mastercard icon" width="40" height="30">
<img id="cc-icon" src="ccicon/amex.png" alt="american express icon" width="40" height="30">
<img id="cc-icon" src="ccicon/discover.png" alt="discover card icon" width="40" height="20">
<div id="cc-type"></div><br>
<span class="error"><font color="red"><?=$ccn_error ?></font></span><br></br>
Card Expiration Date:<br>
<select>
	<option value='1'>01</option>
	<option value='2'>02</option>
	<option value='3'>03</option>
	<option value='4'>04</option>
	<option value='5'>05</option>
	<option value='6'>06</option>
	<option value='7'>07</option>
	<option value='8'>08</option>
	<option value='9'>09</option>
	<option value='10'>10</option>
	<option value='11'>11</option>
	<option value='12'>12</option>
</select>
<select>
	<option value='19'>2019</option>
	<option value='20'>2020</option>
	<option value='21'>2021</option>
	<option value='22'>2022</option>
	<option value='23'>2023</option>
	<option value='24'>2024</option>
	<option value='25'>2025</option>
</select><br></br><br>
Card Security Code:<br>
<input type="password" name="csc" placeholder="Enter 3-4 digit code" value="<?= $csc ?>"><br>
<span class="error"><font color="red"><?=$csc_error ?></font></span><br></br>
<button name="submit">Place order</button>
</div>
</form>
</div>
</body>
<script>
function creditCard() {
	var x = document.getElementById("ccn").value;
	var visa = /^4[0-9]{12}(?:[0-9]{3})?$/;
	var mastercard = /^5[1-5][0-9]{14}$/;
	var amex = /^3[47][0-9]{13}$/;
	var discover = /^6(?:011|5[0-9]{2})[0-9]{12}$/;
    if (visa.test(x)) {
        document.getElementById("cc-type").innerHTML = "<p>Visa</p>";
    }
	if (mastercard.test(x)) {
        document.getElementById("cc-type").innerHTML = "<p>Mastercard</p>";
    }
	if (amex.test(x)) {
        document.getElementById("cc-type").innerHTML = "<p>American Express</p>";
    }
	if (discover.test(x)) {
        document.getElementById("cc-type").innerHTML = "<p>Discover</p>";
    }
}
</script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="menu.js"></script>
</html>