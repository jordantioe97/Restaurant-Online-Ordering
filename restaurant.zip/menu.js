//Julio Soldevilla Code below


window.onload = function () {



    //Images
    document.getElementById('img-l1').src = 'menu-pics\\A_1.jpg';
    document.getElementById('img-l2').src = 'menu-pics\\A_2.jpg';
    document.getElementById('img-r1').src = 'menu-pics\\A_3.jpg';
    document.getElementById('img-r2').src = 'menu-pics\\A_4.jpg';

    document.getElementById('img-l3').src = 'menu-pics\\E_1.jpg';
    document.getElementById('img-l4').src = 'menu-pics\\E_2.jpg';
    document.getElementById('img-r3').src = 'menu-pics\\E_3.jpg';
    document.getElementById('img-r4').src = 'menu-pics\\E_4.jpg';

    document.getElementById('img-l5').src = 'menu-pics\\S_1.jpg';
    document.getElementById('img-l6').src = 'menu-pics\\S_2.jpg';
    document.getElementById('img-r5').src = 'menu-pics\\S_3.jpg';
    document.getElementById('img-r6').src = 'menu-pics\\S_4.jpg';

    document.getElementById('img-l7').src = 'menu-pics\\D_1.jpg';
    document.getElementById('img-l8').src = 'menu-pics\\D_2.jpg';
    document.getElementById('img-r7').src = 'menu-pics\\D_3.jpg';
    document.getElementById('img-r8').src = 'menu-pics\\D_4.jpg';

    //Descriptions
    document.getElementById('desc-l1').innerHTML = 'A piece of bread baked to the perfect temperature and glazed with a buttery blend.';
    document.getElementById('desc-l2').innerHTML = 'A mixture of strawberries, blueberries, kiwis, plums, and raspberries in a yogurt blend.';
    document.getElementById('desc-r1').innerHTML = 'Cooked pasta glazed with creamy tomato sauce and a touch of parsley.';
    document.getElementById('desc-r2').innerHTML = 'A mixture of different types of sushi specializing in their own taste and experience.';

    document.getElementById('desc-l3').innerHTML = 'Pieces of chicken cooked and seasoned with an in-house sauce.';
    document.getElementById('desc-l4').innerHTML = 'A classic blend of cheese, sauce, and pepperoni on a whole wheat crust.';
    document.getElementById('desc-r3').innerHTML = 'Salmon cooked from local ingredients with a glaze of spices and sauces.';
    document.getElementById('desc-r4').innerHTML = 'Steak cooked to any temperature desire and flavored with best spices to best bring out the taste.';

    document.getElementById('desc-l5').innerHTML = 'Fresh potatoes baked to perfection and complimented with sour cream, cheese, and other toppings.';
    document.getElementById('desc-l6').innerHTML = 'Macaroni and cheese with multiples cheeses and a bread crumbs sprinkled on top.';
    document.getElementById('desc-r5').innerHTML = 'Fried potato wedges spiced to perfection.';
    document.getElementById('desc-r6').innerHTML = 'A classic salad for anyone to enjoy.';

    document.getElementById('desc-l7').innerHTML = 'A piece of cheesecake drizzled with a creamy sauce made of different fruits.';
    document.getElementById('desc-l8').innerHTML = 'A chocolate cake with a marshmallow extort that creates a delectable blend.';
    document.getElementById('desc-r7').innerHTML = 'A thin sweet pancake wrapped to encase a multitude of natural fruits.';
    document.getElementById('desc-r8').innerHTML = 'A blend of milk and fruits that create a creamy and frozen delight.';

    //Titles
    document.getElementById('title-l1').innerHTML = 'Bread';
    document.getElementById('title-l2').innerHTML = 'Fruit';
    document.getElementById('title-r1').innerHTML = 'Pasta';
    document.getElementById('title-r2').innerHTML = 'Sushi';

    document.getElementById('title-l3').innerHTML = 'Chicken';
    document.getElementById('title-l4').innerHTML = 'Pizza';
    document.getElementById('title-r3').innerHTML = 'Salmon';
    document.getElementById('title-r4').innerHTML = 'Steak';

    document.getElementById('title-l5').innerHTML = 'Baked Potatoes';
    document.getElementById('title-l6').innerHTML = 'Mac and Cheese';
    document.getElementById('title-r5').innerHTML = 'Potato Wedges';
    document.getElementById('title-r6').innerHTML = 'Salad';

    document.getElementById('title-l7').innerHTML = 'Cheesecake';
    document.getElementById('title-l8').innerHTML = 'Chocolate Marshmallow Cake';
    document.getElementById('title-r7').innerHTML = 'Crepe';
    document.getElementById('title-r8').innerHTML = 'Milkshake';


    //Price
    document.getElementById('price-l1').innerHTML = 'Price: $5.00';
    document.getElementById('price-l2').innerHTML = 'Price: $5.00';
    document.getElementById('price-r1').innerHTML = 'Price: $7.00';
    document.getElementById('price-r2').innerHTML = 'Price: $10.00';

    document.getElementById('price-l3').innerHTML = 'Price: $15.00';
    document.getElementById('price-l4').innerHTML = 'Price: $12.00';
    document.getElementById('price-r3').innerHTML = 'Price: $18.00';
    document.getElementById('price-r4').innerHTML = 'Price: $20.00';

    document.getElementById('price-l5').innerHTML = 'Price: $5.00';
    document.getElementById('price-l6').innerHTML = 'Price: $7.00';
    document.getElementById('price-r5').innerHTML = 'Price: $6.00';
    document.getElementById('price-r6').innerHTML = 'Price: $8.00';

    document.getElementById('price-l7').innerHTML = 'Price: $10.00';
    document.getElementById('price-l8').innerHTML = 'Price: $15.00';
    document.getElementById('price-r7').innerHTML = 'Price: $15.00';
    document.getElementById('price-r8').innerHTML = 'Price: $5.00';



};

var foodId = 0;
var va = 0;
var checkOutArray = new Array();

function addToArray(hi) {
    var foodItem = {
        Name: "",
        Price: "",
        Id: ""
    };;
    var info = hi.slice(4, 6);
    var temp = document.getElementById('price-' + info).innerHTML;
    foodItem.Price = parseInt(temp.slice(8));
    foodItem.Name = document.getElementById('title-' + info).innerHTML;
    foodItem.Id = (foodId);
    foodId++;
    checkOutArray.push(foodItem);
    va = 1;
    alert("Added:" + foodItem.Name);
}


function printArray() {
    var totalF = 0;
    if (va == 1) {
        var end = document.createElement("div");
        document.getElementById('checkoutCont').innerHTML = "";

        for (var i = 0; i < checkOutArray.length; i++) {
            var total = checkOutArray[i].Price;
            var element = document.createElement("div");
            document.getElementById('checkoutCont').appendChild(element);
            element.id = ("checkItem-" + i);
            document.getElementById("checkItem-" + i).innerHTML = checkOutArray[i].Name + '<div style="display:inline;margin-left:30%;">' + '$'+checkOutArray[i].Price + '.00' + '</div>';
            totalF += total;
            va = 0;
        }
        document.getElementById('checkoutCont').appendChild(end);
        end.id = "total";
        document.getElementById('total').innerHTML = "";
		document.getElementById('total').innerHTML ='<hr>' + '<b>' + "Total" + '<div style="display:inline;margin-left:30%;">' + '$'+totalF + '.00' + '</div>' + '</b>';
    }
}

//End of Julio's code
