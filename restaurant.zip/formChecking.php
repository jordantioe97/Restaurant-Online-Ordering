<html>
<body>
<?php
$name_error = $email_error = $address_error = $city_error = $zip_error = $ccn_error = $csc_error = $ccn_type = "";
$name = $email = $address = $city = $zipcode = $ccn = $csc = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["name"])) {
		$name_error = "* Please enter your name";
	} else {
		$name = test_input($_POST["name"]);
		if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
			$name_error = "* Only letters and white spaces allowed";
		}
	}
	if (empty($_POST["email"])) {
		$email_error = "* Please enter your email";
	} else {
		$email = test_input($_POST["email"]);
		if (!preg_match("/^\w+\d*@\w+\.\w{2,3}(\.\w{2,3})?$/",$email)) {
			$email_error = "* Invalid email";
		}
	}
	if (empty($_POST["address"])) {
		$address_error = "* Please enter your address";
	} else {
		$address = test_input($_POST["address"]);
		if (!preg_match("/^[0-9]{3,6}[a-zA-Z ]+$/",$address)) {
			$address_error = "* Invalid address";
		}
	}
	if (empty($_POST["city"])) {
		$city_error = "* Please enter your city";
	} else {
		$city = test_input($_POST["city"]);
	}
	if (empty($_POST["zipcode"])) {
		$zip_error = "* Please enter your zip code";
	} else {
		$zipcode = test_input($_POST["zipcode"]);
		if (!preg_match("/^\d{5}$/",$zipcode)) {
			$zip_error = "* Please enter 5-digit zip code";
		}
	}
	if (empty($_POST["ccn"])) {
		$ccn_error = "* Please enter your card credit card number";
	} else {
		$ccn = test_input($_POST["ccn"]);
		if (preg_match("/^4[0-9]{12}(?:[0-9]{3})?$/",$ccn)) { //visa
		}
		else if (preg_match("/^5[1-5][0-9]{14}$/",$ccn)) { //mastercard
		}
		else if (preg_match("/^3[47][0-9]{13}$/",$ccn)) { //amex
		}
		else if (preg_match("/^6(?:011|5[0-9]{2})[0-9]{12}$/",$ccn)) { //discover
		}
		else
			$ccn_error = "* Credit card is invalid";
	}
	if (empty($_POST["csc"])) {
		$csc_error = "* Please enter your card security code";
	} else {
		$csc = test_input($_POST["csc"]);
		if (!preg_match("/^\d{3,4}$/",$csc)) {
			$csc_error = "* Invalid card security code";
		}
	}
	if ($name_error == '' and $email_error == '' and $address_error == ''
	 and $city_error == '' and $zip_error == '' and $ccn_error == '' and $csc_error == '') {
		$validation = "Form successfully submitted. Delivery is on the way!";
		$name = $email = $address = $city = $zipcode = $ccn = $csc = '';
	}
}

function test_input($data) {
	$data = trim($data);
	$data = stripcslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

?>
</body>
</html>